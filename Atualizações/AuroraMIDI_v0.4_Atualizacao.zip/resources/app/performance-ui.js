'use strict';
// Queue entries hold song identities, so sorting and row deletion never retarget them.
let nextQueue=[],queueAnchor=null,fromQueue=false;
function cleanQueue(){nextQueue=nextQueue.filter(q=>q.list===activeListId&&songs.includes(q.song)&&q.song.parsed);}
function queueSnapshot(){cleanQueue();return nextQueue.map(q=>({index:songs.indexOf(q.song),title:q.song.title||q.song.name}));}
function queueNext(index){const song=songs[index];if(!song?.parsed)return;cleanQueue();if(!nextQueue.some(q=>q.song===song))nextQueue.push({song,list:activeListId});renderQueue();sendPanelFrame(true);toast('A seguir: '+(song.title||song.name)+' ('+nextQueue.length+' na fila)');}
const selectPerformanceSong=selectSong;selectSong=function(i,play=false){if(!fromQueue)queueAnchor=null;return selectPerformanceSong(i,play);};
const nextInPlaylist=nextSong;nextSong=function(direction=1,auto=false){cleanQueue();if(direction>0&&nextQueue.length){const entry=nextQueue.shift();if(!queueAnchor)queueAnchor=songs[selected];fromQueue=true;try{selectSong(songs.indexOf(entry.song),auto||player.playing);}finally{fromQueue=false;}renderPlaylistState();sendPanelFrame(true);return;}
 if(direction>0&&queueAnchor){const order=playableOrder(),anchor=songs.indexOf(queueAnchor),at=order.indexOf(anchor);queueAnchor=null;let next=at+1;if(next>=order.length){if(auto&&!config.repeatAll){playlistPlaying=false;renderPlaylistState();return;}next=0;}if(order[next]!=null){selectSong(order[next],auto||player.playing);renderPlaylistState();return;}}
 return nextInPlaylist(direction,auto);};
const renderPerformanceQueue=renderQueue;renderQueue=function(){renderPerformanceQueue();const queued=queueSnapshot();for(const row of $$('#queueList .queue-item')){const index=Number(row.dataset.index),position=queued.findIndex(q=>q.index===index);const b=document.createElement('button');b.className='queue-next';b.textContent=position<0?'＋':String(position+1);b.title='Tocar a seguir (sem reordenar a playlist)';b.setAttribute('aria-label','Tocar a seguir');b.disabled=!songs[index]?.parsed;b.onclick=()=>queueNext(index);row.querySelector('.delete-song').before(b);}let info=$('#queueNextInfo');if(!info){info=document.createElement('div');info.id='queueNextInfo';info.className='next-queue';$('#queueList').before(info);}info.textContent=queued.length?'A seguir: '+queued.map(q=>q.title).join(' • '):'';};
function startFill(){cleanQueue();const order=playableOrder(),at=order.indexOf(selected);if(!player.playing||player.fill)return;if(!nextQueue.length&&at===order.length-1&&!config.repeatAll){toast('Escolha uma música em Tocar a seguir ou adicione a próxima à playlist.');return;}player.startFill(()=>{const wasRepeat=repeat;repeat=false;nextSong(1,true);repeat=wasRepeat;});}
$('#fill').onclick=startFill;function updateFill(){const b=$('#fill');b.disabled=!player.playing||!!player.fill;b.textContent=player.fill?'Virada…':'Virada';sendPanelFrame(true);}
player.addEventListener('state',updateFill);player.addEventListener('fill',updateFill);
window.desktop?.onPanelsReady?.(()=>{remotePanels=true;sendPanelFrame(true);pushKaraoke();});
renderQueue();

const themeToggle=document.createElement('button');themeToggle.id='themeToggle';themeToggle.className='button small';themeToggle.textContent='Claro / escuro';themeToggle.title='Trocar entre o tema branco e o escuro';themeToggle.onclick=()=>{config.theme=config.theme==='light'?'mint':'light';config.color=config.theme==='light'?'#087e64':'#8df0cc';applyConfig();persist();};$('#compactHeader>div:last-child').prepend(themeToggle);
