const {app,BrowserWindow,ipcMain,dialog,shell,screen,Tray,Menu}=require('electron');
const playlistFiles=require('./playlist-files.cjs');
const {spawn}=require('node:child_process');const path=require('node:path');const fs=require('node:fs');
const panelWindows=new Map();let lastPanelFrame;
let win,karaokeWindow,chordWindow,lastChordFrame,tray,closingAll=false,lastFrame,bridge,ready=false,devices=[],status='Iniciando áudio do Windows…';
function notify(){if(win&&!win.isDestroyed())win.webContents.send('midi-status',{ready,devices,status});}
function startBridge(){
 if(process.platform!=='win32'){status='Sintetizador de prévia';notify();return;}
 bridge=spawn('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'midi-bridge.ps1')],{windowsHide:true,stdio:['pipe','pipe','pipe']});
 let buf='';bridge.stdout.on('data',b=>{buf+=b.toString();let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i).trim();buf=buf.slice(i+1);if(line.startsWith('DEVICE ')){const p=line.split(' ');devices.push({id:Number(p[1]),name:Buffer.from(p[2],'base64').toString('utf8')});}if(line==='READY'){ready=true;status='Áudio MIDI do Windows';notify();}if(line.startsWith('ERROR ')){ready=false;status='Saída MIDI indisponível ('+line.slice(6)+'). Usando prévia.';notify();}}});
 bridge.on('error',()=>{ready=false;status='Áudio Windows indisponível. Usando prévia.';notify();});
 bridge.on('exit',()=>{ready=false;status='Saída MIDI encerrada. Usando sintetizador de prévia.';notify();});bridge.stderr.on('data',()=>{});
}
app.whenReady().then(()=>{if(process.platform==='win32')app.setAppUserModelId('br.aurora.midi');
 win=new BrowserWindow({width:800,height:355,minWidth:730,minHeight:320,backgroundColor:'#0b0d13',icon:path.join(__dirname,'assets','aurora.ico'),title:'Aurora MIDI',autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,backgroundThrottling:false}});
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith('file://'))e.preventDefault();});
 win.on('closed',()=>{closingAll=true;for(const p of panelWindows.values())if(!p.isDestroyed())p.destroy();if(chordWindow&&!chordWindow.isDestroyed())chordWindow.destroy();if(karaokeWindow&&!karaokeWindow.isDestroyed())karaokeWindow.close();app.quit();});win.loadFile('index.html');startBridge();if(process.platform==='win32'){tray=new Tray(path.join(__dirname,'assets','aurora.ico'));tray.setToolTip('Aurora MIDI · Player e acordes');tray.setContextMenu(Menu.buildFromTemplate([{label:'Mostrar player',click:()=>{win.show();win.restore();win.focus();}},{label:'Mostrar acordes',click:()=>openChordWindow()},{type:'separator'},{label:'Encerrar Aurora',click:()=>app.quit()}]));tray.on('double-click',()=>{win.show();win.restore();win.focus();});}
});
function openKaraokeWindow(){
 if(karaokeWindow&&!karaokeWindow.isDestroyed()){karaokeWindow.show();karaokeWindow.restore();karaokeWindow.focus();return;}
 const displays=screen.getAllDisplays(),d=displays.length>1?displays.find(d=>d.id!==screen.getDisplayMatching(win.getBounds()).id):null;
 karaokeWindow=new BrowserWindow({title:'Aurora • Karaokê',width:1100,height:700,...(d?{x:d.workArea.x+30,y:d.workArea.y+30}:{}),backgroundColor:'#13131f',autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
 karaokeWindow.loadFile('stage.html');karaokeWindow.webContents.once('did-finish-load',()=>{if(lastFrame)karaokeWindow?.webContents.send('karaoke-frame',lastFrame);});karaokeWindow.on('closed',()=>karaokeWindow=null);watchWindow(karaokeWindow);
}
ipcMain.on('karaoke-open',openKaraokeWindow);
ipcMain.on('karaoke-frame',(_,frame)=>{if(!frame||typeof frame.html!=='string'||frame.html.length>500000)return;lastFrame=frame;if(karaokeWindow&&!karaokeWindow.isDestroyed())karaokeWindow.webContents.send('karaoke-frame',frame);});
ipcMain.on('karaoke-fullscreen',()=>{if(karaokeWindow&&!karaokeWindow.isDestroyed())karaokeWindow.setFullScreen(!karaokeWindow.isFullScreen());});
ipcMain.handle('midi-state',()=>({ready,devices,status}));
ipcMain.on('midi-send',(_,messages)=>{if(!ready||!Array.isArray(messages)||messages.length>10000)return;let s='';for(const m of messages)if(Array.isArray(m)&&m.length>=1&&m.length<=3&&m.every(n=>Number.isInteger(n)&&n>=0&&n<=255))s+='S '+m.join(' ')+'\n';if(s)bridge?.stdin.writable&&bridge.stdin.write(s);});
ipcMain.on('midi-long',(_,data)=>{if(ready&&Array.isArray(data)&&data.length<=1048576&&data.every(v=>Number.isInteger(v)&&v>=0&&v<=255)&&bridge?.stdin.writable)bridge.stdin.write('L '+Buffer.from(data).toString('hex')+'\n');});
ipcMain.on('midi-reset',()=>{if(bridge?.stdin.writable)bridge.stdin.write('RESET\n');});
ipcMain.on('midi-open',(_,id)=>{if(Number.isInteger(id)&&id>=-1&&id<devices.length&&bridge?.stdin.writable)bridge.stdin.write('OPEN '+id+'\n');});
ipcMain.handle('save-file',async(_,name,bytes)=>{if(typeof name!=='string'||(!(bytes instanceof Uint8Array)&&!Array.isArray(bytes))||bytes.length>300*1024*1024)return false;const r=await dialog.showSaveDialog(win,{defaultPath:path.basename(name)});if(r.canceled)return false;await fs.promises.writeFile(r.filePath,Buffer.from(bytes));return true;});

function openChordWindow(){
 if(chordWindow&&!chordWindow.isDestroyed()){chordWindow.show();chordWindow.restore();chordWindow.focus();return;}
 chordWindow=new BrowserWindow({title:'Aurora · Acordes',width:700,height:650,minWidth:450,minHeight:250,icon:path.join(__dirname,'assets','aurora.ico'),backgroundColor:'#101a17',autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
 chordWindow.loadFile('chord-stage.html');chordWindow.webContents.once('did-finish-load',()=>{if(lastChordFrame)chordWindow?.webContents.send('chord-frame',lastChordFrame);});chordWindow.on('close',e=>{if(!closingAll){e.preventDefault();chordWindow.minimize();}});chordWindow.on('closed',()=>chordWindow=null);watchWindow(chordWindow);
}
ipcMain.on('chord-open',()=>openChordWindow());
ipcMain.on('chord-frame',(_,frame)=>{if(!frame||typeof frame.html!=='string'||frame.html.length>500000)return;lastChordFrame=frame;if(chordWindow&&!chordWindow.isDestroyed())chordWindow.webContents.send('chord-frame',frame);});
ipcMain.on('chord-action',(_,action)=>{if(['freeze','capo','copy','compact'].includes(action)&&win&&!win.isDestroyed())win.webContents.send('chord-action',action);});
function openPanelWindow(type){if(!['mixer','piano','playlist','controls'].includes(type))return;let panel=panelWindows.get(type);if(panel&&!panel.isDestroyed()){panel.show();panel.focus();return;}panel=new BrowserWindow({title:'Aurora · '+({mixer:'Mixer',piano:'Piano',playlist:'Playlist',controls:'Controles'}[type]),width:type==='piano'?1100:type==='playlist'?820:850,height:type==='piano'?340:type==='controls'?430:650,minWidth:700,minHeight:250,icon:path.join(__dirname,'assets','aurora.ico'),backgroundColor:'#10191a',autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});panelWindows.set(type,panel);panel.loadFile('panel-stage.html',{query:{type}});panel.webContents.once('did-finish-load',()=>{if(lastPanelFrame)panel.webContents.send('panel-frame',lastPanelFrame);});panel.on('closed',()=>panelWindows.delete(type));watchWindow(panel);}
ipcMain.on('panel-open',(_,type)=>openPanelWindow(type));
ipcMain.on('panel-frame',(_,frame)=>{if(!frame||!Array.isArray(frame.channels)||frame.channels.length>16||!Array.isArray(frame.notes)||frame.notes.length>2048)return;lastPanelFrame=frame;for(const panel of panelWindows.values())if(!panel.isDestroyed())panel.webContents.send('panel-frame',frame);});
const panelActions=['mute','solo','reduce','volume','program','note-on','note-off','reset-channel','reset-mix','save-mix','load-mix','save-midi','play','pause','stop','next','prev','seek','speed','transpose','gain','master','reset-controls','sort','search','filter','play-playlist','select-song','move-up','move-down','move-song','open-midi','open-vpl','save-vpl','backup','create-list','rename-list','delete-list','switch-list','clear-list','remove-song'];
ipcMain.on('panel-action',(_,action)=>{if(action&&panelActions.includes(action.kind)&&win&&!win.isDestroyed())win.webContents.send('panel-action',action);});
let compactLayout=true;
function publishWindows(){if(!win||win.isDestroyed())return;const visible=w=>!!w&&!w.isDestroyed()&&w.isVisible()&&!w.isMinimized();win.webContents.send('window-state',{playlist:visible(panelWindows.get('playlist')),controls:visible(panelWindows.get('controls')),mixer:visible(panelWindows.get('mixer')),piano:visible(panelWindows.get('piano')),karaoke:visible(karaokeWindow),chords:visible(chordWindow)});}
function watchWindow(w){for(const name of ['show','hide','minimize','restore','closed'])w.on(name,publishWindows);publishWindows();}
ipcMain.on('window-toggle',(_,type)=>{if(!['playlist','controls','mixer','piano','karaoke','chords'].includes(type))return;const w=type==='karaoke'?karaokeWindow:type==='chords'?chordWindow:panelWindows.get(type);if(w&&!w.isDestroyed()){if(w.isVisible()&&!w.isMinimized())w.hide();else{w.show();w.restore();w.focus();}publishWindows();return;}if(type==='karaoke')openKaraokeWindow();else if(type==='chords')openChordWindow();else openPanelWindow(type);});
ipcMain.on('compact-mode',(_,compact)=>{compact=!!compact;if(!win||win.isDestroyed()||compact===compactLayout)return;compactLayout=compact;win.setMinimumSize(compact?730:1080,compact?320:730);win.setSize(compact?800:1440,compact?355:950);publishWindows();});

function route(name,fn){ipcMain.handle(name,async(e,...args)=>{try{return await fn(e,...args);}catch(err){return {error:err.message};}});}
route('save-song-as',async(_,name,bytes,originalPath)=>{
 if(typeof name!=='string'||(!(bytes instanceof Uint8Array)&&!Array.isArray(bytes))||bytes.length>100*1024*1024)throw Error('MIDI inválido.');
 const canonical=async p=>{try{return await fs.promises.realpath(p);}catch{return path.resolve(p);}};
 const source=originalPath?await canonical(originalPath):null;
 while(true){const r=await dialog.showSaveDialog(win,{defaultPath:path.basename(name),filters:[{name:'MIDI e karaokê',extensions:['mid','kar']}]});if(r.canceled)return false;let target=await canonical(r.filePath),same=source&&(process.platform==='win32'?target.toLowerCase()===source.toLowerCase():target===source);
 if(source&&!same)try{let a=await fs.promises.stat(source),b=await fs.promises.stat(target);same=!!a.ino&&a.ino===b.ino&&a.dev===b.dev;}catch{}
 if(same){await dialog.showMessageBox(win,{type:'info',message:'Escolha outro nome para preservar o MIDI original.',detail:'A mix personalizada será salva como uma cópia.',buttons:['Escolher outro nome']});continue;}
 await fs.promises.writeFile(r.filePath,Buffer.from(bytes));return {path:r.filePath};}
});
route('choose-midis',async()=>{const r=await dialog.showOpenDialog(win,{properties:['openFile','multiSelections'],filters:[{name:'MIDI e karaokê',extensions:['mid','midi','kar','rmi']}]});if(r.canceled)return {files:[]};let files=[],errors=[];for(const p of r.filePaths.slice(0,500))try{files.push(await playlistFiles.readMidi(p));}catch(e){errors.push(path.basename(p)+': '+e.message);}return {files,errors};});
route('choose-folder',async()=>{const r=await dialog.showOpenDialog(win,{properties:['openDirectory']});if(r.canceled)return {files:[]};const paths=await playlistFiles.findFiles(r.filePaths[0],500);let files=[];for(const p of paths)try{files.push(await playlistFiles.readMidi(p));}catch{}return {files,folder:r.filePaths[0]};});
route('import-playlist',async()=>{const r=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'Playlists VanBasco / Aurora',extensions:['vpl','aurora','json']}]});if(r.canceled)return null;let p=r.filePaths[0];if(!/\.vpl$/i.test(p))return {kind:'aurora',name:path.basename(p),bytes:new Uint8Array(await fs.promises.readFile(p))};let doc=await playlistFiles.loadVpl(p);if(doc.missing){const ask=await dialog.showMessageBox(win,{type:'question',message:doc.missing+' arquivo(s) da lista não foram encontrados.',detail:'Um VPL guarda os caminhos, sem incluir os arquivos MIDI. Você pode indicar a pasta onde as músicas estão agora.',buttons:['Localizar pasta das músicas','Manter entradas ausentes'],defaultId:0,cancelId:1});if(ask.response===0){const folder=await dialog.showOpenDialog(win,{properties:['openDirectory']});if(!folder.canceled)doc=await playlistFiles.loadVpl(p,folder.filePaths[0]);}}return {kind:'vpl',doc};});
route('relink-playlist',async(_,file)=>{if(typeof file!=='string'||!/\.vpl$/i.test(file))throw Error('Importe o VPL novamente para localizar as músicas.');const r=await dialog.showOpenDialog(win,{properties:['openDirectory']});return r.canceled?null:{kind:'vpl',doc:await playlistFiles.loadVpl(file,r.filePaths[0])};});
route('save-vpl',async(_,name,entries)=>{const r=await dialog.showSaveDialog(win,{defaultPath:path.basename(name||'Playlist')+'.vpl',filters:[{name:'Playlist VanBasco',extensions:['vpl']}]});if(r.canceled)return null;const p=/\.vpl$/i.test(r.filePath)?r.filePath:r.filePath+'.vpl';return playlistFiles.saveVpl(p,name,entries);});
ipcMain.on('always-top',(e,enabled)=>BrowserWindow.fromWebContents(e.sender)?.setAlwaysOnTop(!!enabled));
app.on('window-all-closed',()=>app.quit());app.on('before-quit',()=>{closingAll=true;tray?.destroy();if(chordWindow&&!chordWindow.isDestroyed())chordWindow.destroy();try{bridge?.stdin.write('QUIT\n');bridge?.stdin.end();}catch{}setTimeout(()=>bridge?.kill(),100).unref();});
